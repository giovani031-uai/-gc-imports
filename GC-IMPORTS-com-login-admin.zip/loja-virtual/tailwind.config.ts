import type { Config } from "tailwindcss";
const config:Config={content:["./app/**/*.{ts,tsx}","./components/**/*.{ts,tsx}","./lib/**/*.{ts,tsx}"],theme:{extend:{colors:{orange:"#ff5c00",ink:"#f7f7f7"},maxWidth:{content:"1180px"}}},plugins:[]};export default config;

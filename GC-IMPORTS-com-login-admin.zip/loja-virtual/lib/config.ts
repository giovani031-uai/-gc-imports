export const storeConfig = {
  name: "GC IMPORTS",
  shortName: "GC",
  tagline: "Tecnologia certa. Do seu jeito.",
  description: "Computadores, peças e tecnologia selecionada com atendimento direto pelo WhatsApp.",
  whatsapp: {
    number: "5531991020519",
    display: "(31) 99102-0519",
    defaultMessage: (productName?: string) => productName ? `Olá! Tenho interesse no produto ${productName}.` : "Olá! Vim pelo site da GC IMPORTS e gostaria de tirar uma dúvida.",
  },
  social: { instagram: "" },
  contactEmail: "contato@gcinformatica.com.br",
};

export const categories = [
  { slug: "pc-gamer", name: "PC Gamer", icon: "Monitor" },
  { slug: "placas-de-video", name: "Placas de Vídeo", icon: "Cpu" },
  { slug: "processadores", name: "Processadores", icon: "Cpu" },
  { slug: "memorias", name: "Memórias RAM", icon: "MemoryStick" },
  { slug: "armazenamento", name: "SSD e Armazenamento", icon: "HardDrive" },
  { slug: "perifericos", name: "Periféricos", icon: "Keyboard" },
  { slug: "monitores", name: "Monitores", icon: "Monitor" },
  { slug: "componentes", name: "Componentes", icon: "CircuitBoard" },
];

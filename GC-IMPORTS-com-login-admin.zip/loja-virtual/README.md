# GC IMPORTS — loja online

Projeto Next.js preparado para uma operação de venda sob demanda (sem estoque físico próprio).

## O que já está pronto
- Homepage profissional e responsiva
- Header/footer e identidade GC IMPORTS
- WhatsApp (31) 99102-0519
- Categorias, catálogo, busca e filtro
- Carrinho persistido no navegador
- Checkout preparado
- Página de montagem de PC com envio para WhatsApp
- Área de conta/login (estrutura pronta para Supabase)
- Painel administrativo inicial
- Modelo SQL para produtos, pedidos, itens e configurações
- Variáveis de ambiente para Supabase e gateway de pagamento

## O que falta para produção
1. Criar/configurar o projeto Supabase e executar `supabase-schema.sql`.
2. Implementar autenticação real e políticas RLS.
3. Criar CRUD real do painel admin conectado ao Supabase.
4. Escolher um gateway (ex.: Mercado Pago, Stripe ou outro disponível para sua operação) e inserir as chaves.
5. Implementar webhooks do gateway para confirmar pagamentos.
6. Cadastrar fornecedores e produtos.
7. Definir política de frete, prazo, troca e responsabilidade do fornecedor.

## Rodar localmente
```bash
npm install
npm run dev
```
Abra http://localhost:3000.

## Publicar
O projeto é compatível com Vercel. Suba o repositório ou importe o projeto e configure as variáveis de ambiente antes do deploy de produção.

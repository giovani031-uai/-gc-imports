# Login administrativo — GC IMPORTS

Usuário padrão: Giovani
A senha não é gravada em texto puro no código.

Para produção, configure no Vercel as variáveis ADMIN_USERNAME e ADMIN_PASSWORD_HASH usando os valores do .env.example.
Depois faça um novo deploy.

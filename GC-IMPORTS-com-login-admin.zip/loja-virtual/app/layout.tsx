import "./globals.css";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { CartProvider } from "@/components/shop/CartProvider";
import { storeConfig } from "@/lib/config";

export const metadata = { title: { default: storeConfig.name, template: `%s | ${storeConfig.name}` }, description: storeConfig.description };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="pt-BR"><body><CartProvider><Header />{children}<Footer /></CartProvider></body></html>;
}

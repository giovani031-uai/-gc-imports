'use client';

import { FormEvent, useState } from 'react';
import { useRouter } from 'next/navigation';

export default function AdminLoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      if (!res.ok) {
        setError('Usuário ou senha inválidos.');
        return;
      }
      router.replace('/admin/painel');
      router.refresh();
    } catch {
      setError('Não foi possível entrar. Tente novamente.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen flex items-center justify-center p-6 bg-slate-950">
      <form onSubmit={submit} className="w-full max-w-md rounded-2xl border border-white/10 bg-white/5 p-7 shadow-2xl">
        <h1 className="text-2xl font-bold text-white">GC IMPORTS — Administrador</h1>
        <p className="mt-2 text-sm text-white/60">Entre para acessar o painel administrativo.</p>
        <label className="mt-6 block text-sm text-white/80">Usuário</label>
        <input value={username} onChange={e=>setUsername(e.target.value)} autoComplete="username"
          className="mt-2 w-full rounded-xl bg-white/10 px-4 py-3 text-white outline-none" />
        <label className="mt-4 block text-sm text-white/80">Senha</label>
        <input value={password} onChange={e=>setPassword(e.target.value)} type="password" autoComplete="current-password"
          className="mt-2 w-full rounded-xl bg-white/10 px-4 py-3 text-white outline-none" />
        {error && <p className="mt-3 text-sm text-red-400">{error}</p>}
        <button disabled={loading} className="mt-6 w-full rounded-xl bg-orange-500 px-4 py-3 font-semibold text-white disabled:opacity-60">
          {loading ? 'Entrando...' : 'Entrar'}
        </button>
      </form>
    </main>
  );
}

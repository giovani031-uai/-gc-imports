import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';

export default async function AdminPanelPage() {
  const c = await cookies();
  if (!c.get('gc_admin_session')?.value) redirect('/admin');

  return (
    <main className="min-h-screen p-6">
      <div className="mx-auto max-w-6xl">
        <h1 className="text-3xl font-bold">Painel Administrativo — GC IMPORTS</h1>
        <p className="mt-2 opacity-70">Área protegida. Aqui ficará o gerenciamento de produtos, pedidos e estoque.</p>
      </div>
    </main>
  );
}

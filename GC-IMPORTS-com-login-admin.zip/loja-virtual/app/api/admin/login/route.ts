import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import crypto from 'node:crypto';

const USERNAME = process.env.ADMIN_USERNAME || 'Giovani';
const PASSWORD_HASH = process.env.ADMIN_PASSWORD_HASH || 'a9dfb16d45dab2d7cb55df6733f3778d6173cf8b834f4ba2313b522c094b5e06';

function hashPassword(value: string) {
  return crypto.createHash('sha256').update('gc-imports-admin-v1:' + value).digest('hex');
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  const username = String(body.username || '');
  const password = String(body.password || '');

  if (username !== USERNAME || hashPassword(password) !== PASSWORD_HASH) {
    return NextResponse.json({ ok: false }, { status: 401 });
  }

  const store = await cookies();
  store.set('gc_admin_session', crypto.randomBytes(32).toString('hex'), {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/admin',
    maxAge: 60 * 60 * 8,
  });

  return NextResponse.json({ ok: true });
}

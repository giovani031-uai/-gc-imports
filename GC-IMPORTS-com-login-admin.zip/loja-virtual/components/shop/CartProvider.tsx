"use client";
import { createContext, useContext, useEffect, useMemo, useState } from "react";
export type CartItem = { id:string; name:string; price:number; image?:string; quantity:number };
type CartCtx={items:CartItem[]; add:(p:Omit<CartItem,"quantity">)=>void; remove:(id:string)=>void; setQty:(id:string,q:number)=>void; clear:()=>void; total:number; count:number};
const C=createContext<CartCtx|null>(null);
export function CartProvider({children}:{children:React.ReactNode}){const [items,setItems]=useState<CartItem[]>([]); useEffect(()=>{try{setItems(JSON.parse(localStorage.getItem("gc-cart")||"[]"))}catch{}},[]); useEffect(()=>localStorage.setItem("gc-cart",JSON.stringify(items)),[items]); const value=useMemo(()=>({items,add:(p:Omit<CartItem,"quantity">)=>setItems(x=>{const e=x.find(i=>i.id===p.id);return e?x.map(i=>i.id===p.id?{...i,quantity:i.quantity+1}:i):[...x,{...p,quantity:1}]}),remove:(id:string)=>setItems(x=>x.filter(i=>i.id!==id)),setQty:(id:string,q:number)=>setItems(x=>q<=0?x.filter(i=>i.id!==id):x.map(i=>i.id===id?{...i,quantity:q}:i)),clear:()=>setItems([]),total:items.reduce((s,i)=>s+i.price*i.quantity,0),count:items.reduce((s,i)=>s+i.quantity,0)}),[items]); return <C.Provider value={value}>{children}</C.Provider>}
export const useCart=()=>{const c=useContext(C);if(!c)throw new Error("useCart must be used inside CartProvider");return c};

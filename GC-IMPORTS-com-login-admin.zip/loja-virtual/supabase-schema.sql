-- Banco inicial para GC INFORMATICA / modelo sem estoque próprio.
create table if not exists public.products (
 id uuid primary key default gen_random_uuid(),
 name text not null, slug text unique not null, description text, category text,
 price numeric(12,2) not null default 0, supplier_name text, supplier_sku text,
 supplier_url text, stock_status text default 'available', image_url text,
 featured boolean default false, active boolean default true,
 created_at timestamptz default now(), updated_at timestamptz default now()
);
create table if not exists public.orders (
 id uuid primary key default gen_random_uuid(), user_id uuid references auth.users(id),
 customer_name text not null, email text, phone text, address text, city text,
 payment_method text, payment_status text default 'pending', order_status text default 'new',
 total numeric(12,2) not null default 0, supplier_status text default 'pending',
 supplier_order_reference text, created_at timestamptz default now(), updated_at timestamptz default now()
);
create table if not exists public.order_items (
 id uuid primary key default gen_random_uuid(), order_id uuid references public.orders(id) on delete cascade,
 product_id uuid references public.products(id), product_name text not null, quantity integer not null, unit_price numeric(12,2) not null
);
create table if not exists public.settings (
 key text primary key, value jsonb not null default '{}'::jsonb, updated_at timestamptz default now()
);
-- Para produção: habilite RLS e crie políticas por usuário/admin conforme sua estratégia de autenticação.
